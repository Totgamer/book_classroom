<div class="row">
<div class="col-md-12">
    <?php echo "<h1 class='time text-success'>" . date("h:i:s") . "</h1>"; ?>
</div>
</div>

<div class="row">
<div class="col-md-12">
    <?php echo "<h3 class='date text-secondary'>" . date("d-m-Y") . "</h3>"; ?>
</div>
</div>
